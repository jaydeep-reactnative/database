//
//  JsonParser.h
//  JsonDemoDay2
//
//  Created by Tosc163 on 26/08/16.
//  Copyright © 2016 SQUAD. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger,ParsingTypeList)
{
    PARSING_JSON_LIST,
    PASING_XML_LIST
};

@protocol jsonParserDelegate <NSObject>

@required

-(void)parsingCompleteWithSuccess : (NSString *)successMessage : (NSArray *) arrData;

-(void)parsingFailedWithError: (NSString *)errorMessage;

@end


@interface JsonParser : NSObject

@property (weak,nonatomic) id<jsonParserDelegate>delegate;

-(void)parse;

@end
