//
//  JsonHelper.h
//  JsonDemoDay2
//
//  Created by Tosc163 on 26/08/16.
//  Copyright © 2016 SQUAD. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol JsonHelperDelegate <NSObject>

@required

-(void)jsonListSuccess : (NSString *)successMessage : (NSArray *) arrData;

-(void)jsonListFailure : (NSString *)errorMessage;

@end

@interface JsonHelper : NSObject

@property (weak,nonatomic) id <JsonHelperDelegate> delegate;

@property (strong,nonatomic) NSString *strSubmitURL;

-(void)jsonData;

@end
