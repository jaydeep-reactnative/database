//
//  JsonList.h
//  JsonDemoDay2
//
//  Created by Tosc163 on 26/08/16.
//  Copyright © 2016 SQUAD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JsonList : NSObject

@property (nonatomic,strong) NSMutableDictionary *dictCityList;

@end
