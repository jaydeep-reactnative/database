//
//  JsonParser.h
//  JsonDemo
//
//  Created by Tosc163 on 25/08/16.
//  Copyright © 2016 SQUAD. All rights reserved.
//

#import <Foundation/Foundation.h>


typedef NS_ENUM(NSUInteger, ParsingTypeOfferList)
{
    PARSING_JSON_OFFER_LIST,
    PARSING_XML_OFFER_LIST
};


#pragma mark -
#pragma mark PARSER DELEGATE -

@protocol JsonParserDelegate <NSObject>

@required

-(void)parsingCompleteWithSuccess: (NSString *)successMessage : (NSArray *)arrData;

-(void)parsingFailedWithError:(NSString *)errorMesssage;

@end


#pragma mark -
#pragma mark PARSER INTERFACE -

@interface JsonParser : NSObject

@property (weak,nonatomic) id<JsonParserDelegate>delegate;

- (void)parse;

- (id)initUsingData : (NSData *)data type : (ParsingTypeOfferList)parsingTypeOfferList;


@end
