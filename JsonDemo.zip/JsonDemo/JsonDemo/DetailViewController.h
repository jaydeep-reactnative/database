//
//  DetailViewController.h
//  JsonDemo
//
//  Created by Tosc163 on 26/08/16.
//  Copyright © 2016 SQUAD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController

@property (strong, nonatomic) IBOutlet UILabel *lblId;

@property (strong, nonatomic) IBOutlet UIImageView *ivCityImage;

@property (strong, nonatomic) IBOutlet UILabel *lblCategoryName;

@property (strong, nonatomic) IBOutlet UILabel *lblCityName;

@property (strong, nonatomic) IBOutlet UILabel *lblHotDealFlag;

@property (strong, nonatomic) IBOutlet UILabel *lblHotDealValue;

@property (strong, nonatomic) IBOutlet UILabel *lblSubCategoryId;

@property (strong, nonatomic) IBOutlet UILabel *lblSubCategoryName;

@property (strong, nonatomic) NSString *strId;

@property (strong, nonatomic) NSString *strCityImage;

@property (strong, nonatomic) NSString *strCategoryName;

@property (strong, nonatomic) NSString *strCityName;

@property (strong, nonatomic) NSString *strHotDealFlag;

@property (strong, nonatomic) NSString *strHotDealValue;

@property (strong, nonatomic) NSString *strSubCategoryId;

@property (strong, nonatomic) NSString *strSubCategoryName;

@end
