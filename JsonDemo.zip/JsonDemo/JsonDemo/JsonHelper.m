//
//  jsonHelper.m
//  JsonDemo
//
//  Created by Tosc163 on 25/08/16.
//  Copyright © 2016 SQUAD. All rights reserved.
//

#import "JsonHelper.h"
#import "JsonList.h"


#pragma mark -
#pragma mark HELPER INTERFACE -

@interface JsonHelper () <JsonParserDelegate>

{
    NSMutableURLRequest *request;
    
    JsonParser *jsonParser;
    
    NSString *error;
}

@end


#pragma mark -
#pragma mark HELPER IMPLEMENTATION -

@implementation JsonHelper

@synthesize delegate;

@synthesize parsingType;

@synthesize strSubmitURL;


#pragma mark -
#pragma mark jsonData Method -

-(void)jsonData
{
    NSLog(@"jsonData Called");
    
    NSOperationQueue *queue = [[NSOperationQueue alloc] init];
        
    request = [[NSMutableURLRequest alloc]init];
    
    [request setURL:[NSURL URLWithString:strSubmitURL]];
    
    [request setHTTPMethod:@"GET"];
    
    [NSURLConnection sendAsynchronousRequest:request
                                       queue:queue
                           completionHandler:^(NSURLResponse *response, NSData *data, NSError *error)
     {
         if(data)
         {
             jsonParser = [[JsonParser alloc]initUsingData:data type:parsingType];
             
             jsonParser.delegate = self;
             
             [jsonParser parse];
         }
     }];
}

#pragma mark -
#pragma mark PARSER DELEGATE METHODS  -

-(void)parsingCompleteWithSuccess: (NSString *)successMessage : (NSArray *)arrData
{
        NSLog(@"Parsing Complete With Success Called");
    
        [delegate jsonListSuccess:successMessage :arrData];
}

-(void)parsingFailedWithError:(NSString *)errorMesssage
{
        [delegate jsonListFailure:errorMesssage];
}

@end