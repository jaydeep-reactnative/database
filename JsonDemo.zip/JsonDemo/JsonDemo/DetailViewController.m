//
//  DetailViewController.m
//  JsonDemo
//
//  Created by Tosc163 on 26/08/16.
//  Copyright © 2016 SQUAD. All rights reserved.
//

#import "DetailViewController.h"

@interface DetailViewController ()

@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.navigationController setNavigationBarHidden:NO];
    
    self.ivCityImage.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:
                                                     [NSURL URLWithString:[NSString stringWithFormat:@"%@",self.strCityImage]]]];
    
    self.lblId.text = self.strId;
    self.lblCategoryName.text = self.strCategoryName;
    self.lblCityName.text = self.strCityName;
    self.lblHotDealValue.text = self.strHotDealValue;
    self.lblSubCategoryId.text = self.strSubCategoryId;
    self.lblSubCategoryName.text = self.strSubCategoryName;
    
    
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
