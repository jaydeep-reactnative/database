//
//  JsonList.h
//  JsonDemo
//
//  Created by Tosc163 on 25/08/16.
//  Copyright © 2016 SQUAD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JsonList : NSObject

@property (nonatomic,retain) NSString *strId;

@property (nonatomic,retain) NSString *strCategoryName;

@property (nonatomic,retain) NSString *strCityName;

@property (nonatomic,strong) NSString *strCityImage;

@property (nonatomic,retain) NSString *strHotDealValue;

@property (nonatomic,retain) NSString *strSubCatName;

@property (nonatomic) Boolean hotDealFlag;

@end
