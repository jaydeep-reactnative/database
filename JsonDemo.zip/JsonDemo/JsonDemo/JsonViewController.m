//
//  JsonViewController.m
//  JsonDemo
//
//  Created by Tosc163 on 25/08/16.
//  Copyright © 2016 SQUAD. All rights reserved.
//

#import "JsonViewController.h"
#import "JsonHelper.h"
#import "TableViewCell.h"
#import "JsonList.h"
#import "DetailViewController.h"

@interface JsonViewController () <jsonHelperDelegate>
{
    JsonHelper *tempJsonHelper;
    TableViewCell *tableViewCell;
    NSMutableArray *arrList;
    JsonList *jsonList;
}

@end

@implementation JsonViewController


#pragma mark -
#pragma mark VIEW DID LOAD -

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self.activityIndicator setFrame:CGRectMake(140,284, self.activityIndicator.frame.size.width, self.activityIndicator.frame.size.height)];
    
    [self.view addSubview:self.activityIndicator];
    
//    [self jsonParsing];
    
    [self cityListParsing];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];

}

-(void)viewWillAppear:(BOOL)animated
{
    [self.navigationController setNavigationBarHidden:YES];
}

-(void)xmlParsing
{

    tempJsonHelper = [[JsonHelper alloc]init];
    
    tempJsonHelper.strSubmitURL  = @"https://api/test/test";
    
    tempJsonHelper.parsingType = PARSING_XML_OFFER_LIST;
    
    tempJsonHelper.delegate = self;
    
    [tempJsonHelper jsonData];

}

-(void)cityListParsing
{
    tempJsonHelper = [[JsonHelper alloc]init];
    
    tempJsonHelper.strSubmitURL  = @"http://192.168.0.10/~ashishp/CitySwag/citylist.json";
    
    tempJsonHelper.parsingType = PARSING_JSON_OFFER_LIST;
    
    tempJsonHelper.delegate = self;
    
    [tempJsonHelper jsonData];
}

#pragma mark -
#pragma mark JSON PARSING METHOD -

-(void)jsonParsing
{
    tempJsonHelper = [[JsonHelper alloc]init];
    
    [self.activityIndicator startAnimating];
    
    tempJsonHelper.strSubmitURL  = @"https://api.github.com/events";

    tempJsonHelper.parsingType = PARSING_JSON_OFFER_LIST;

    tempJsonHelper.delegate = self;
    
    [tempJsonHelper jsonData];

}

#pragma mark -
#pragma mark HELPER DELEGATE METHODS -

-(void)jsonListSuccess:(NSString *)successMessage :(NSArray *)arrData
{
    NSLog(@"Json List Success Called");
    
    [self.activityIndicator stopAnimating];
    
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Json Parsing"
                                                   message:successMessage
                                                  delegate:nil
                                         cancelButtonTitle:nil
                                         otherButtonTitles:@"OK", nil];
    
    [alert show];
    
    arrList = [[NSMutableArray alloc]init];
    
    arrList = [arrData mutableCopy];
    
    NSLog(@"==================================================================");
    NSLog(@"%@",arrList);
    
    [self.tableView reloadData];
}

-(void)jsonListFailure:(NSString *)errorMessage
{
    [self.activityIndicator stopAnimating];
    
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Json Parsing"
                                                   message:errorMessage
                                                  delegate:nil
                                         cancelButtonTitle:nil
                                         otherButtonTitles:@"OK", nil];
    
    [alert show];
}

#pragma mark -
#pragma mark TABLEVIEW METHODS -

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrList count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *strIdentifier = @"TableViewCell";
   
    tableViewCell = [tableView dequeueReusableCellWithIdentifier:strIdentifier];
    
    if (tableViewCell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:strIdentifier owner:self options:nil];
        tableViewCell = nib[0];
    }
    
    jsonList = (JsonList*) [arrList objectAtIndex:indexPath.row];
    
    tableViewCell.ivCityImage.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:
                                                [NSURL URLWithString:[NSString stringWithFormat:@"%@",jsonList.strCityImage]]]];
    
    tableViewCell.lblCityName.text = jsonList.strCityName;
    
    return tableViewCell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    DetailViewController *detailViewController = [[DetailViewController alloc]initWithNibName:@"DetailViewController" bundle:nil];
    detailViewController.strCityImage = jsonList.strCityImage;
    detailViewController.strId = jsonList.strId;
    detailViewController.strCategoryName = jsonList.strCategoryName;
    detailViewController.strCityName = jsonList.strCityName;
//    detailViewController.strHotDealFlag = jsonList.str;
    detailViewController.strHotDealValue = jsonList.strHotDealValue;
    detailViewController.strSubCategoryName = jsonList.strSubCatName;
//    detailViewController.strCategoryName = jsonList.strCategoryName;
    
    
    [self.navigationController pushViewController:detailViewController animated:YES];

}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 165;
}

@end
