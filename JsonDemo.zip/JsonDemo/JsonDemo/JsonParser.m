//
//  JsonParser.m
//  JsonDemo
//
//  Created by Tosc163 on 25/08/16.
//  Copyright © 2016 SQUAD. All rights reserved.
//

#import "JsonParser.h"
#import "JsonList.h"
#import "AppDelegate.h"
#import "JsonViewController.h"

#pragma mark -
#pragma mark PARSER INTERFACE -

@interface JsonParser ()

{
    AppDelegate *appDelegate;
    
    NSUserDefaults *prefs;

    NSData *dataOfferList;

    ParsingTypeOfferList type;
    
    NSMutableArray *arrCitylist;

    unsigned int intStatus;
}

-(void)parseUsingJson;

@end


#pragma mark -
#pragma mark PARSER IMPLEMENTATION -

@implementation JsonParser

@synthesize delegate;

- (id)initUsingData : (NSData *)data type : (ParsingTypeOfferList)parsingTypeOfferList
{
    if(self = [super init])
    {
        appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
        prefs = [NSUserDefaults standardUserDefaults];
        
        dataOfferList = data;
        type = parsingTypeOfferList;
        return self;
    }
    
    return nil;
}

#pragma mark -
#pragma mark PARSE METHOD -

- (void)parse
{

    NSLog(@"parse Called");

    if(type == PARSING_JSON_OFFER_LIST)
    {
//        [self parseUsingJson];
        
        [self parseCityList];
    }
    else if (type == PARSING_XML_OFFER_LIST)
    {
        
    }
}

#pragma mark -
#pragma mark PARSE USING JSON METHOD -

-(void)parseUsingJson
{
    NSLog(@"parseUsingJson Called");
    
    if(dataOfferList == nil)
    {
        [delegate parsingFailedWithError:@"Internet connection not currently available."];
    }
    else
    {
        NSString *strResponse = [[NSString alloc] initWithData:dataOfferList encoding:NSStringEncodingConversionAllowLossy];
        
        NSLog(@"Response Data For Offer List :- %@", strResponse);
        
        dataOfferList = [strResponse dataUsingEncoding:NSUTF8StringEncoding];
        
        NSError *jsonError;
        
         NSArray *arrJosnList = [NSJSONSerialization JSONObjectWithData:dataOfferList
                                                                      options:kNilOptions
                                                                        error:&jsonError];
        
        if(jsonError != nil)
        {
            [delegate parsingFailedWithError:[NSString stringWithFormat:NSLocalizedString(@"Text-Alert-JSON-Error", nil)]];
            
            [self.delegate parsingFailedWithError:@"Json Parsing Fail"];
        }
        else
        {
            NSMutableArray *tmpArrJsonList = [[NSMutableArray alloc] init];
            
            
                for(int j = 0 ; j < [arrJosnList count] ; j++)
                {
                    
                    NSDictionary *discJson = [arrJosnList objectAtIndex:j];
                    
                    JsonList *jsonList = [[JsonList alloc] init];
                    
//                    if([discJson objectForKey:@"id"] == [NSNull null])
//                       jsonList.strId = @"";
//                    else
//                        jsonList.strId = [discJson objectForKey:@"id"];
//                    
//                    if([discJson objectForKey:@"type"] == [NSNull null])
//                        jsonList.strType = @"";
//                    else
//                        jsonList.strType = [discJson objectForKey:@"type"];
//                    
//                    if([discJson objectForKey:@"actor"] == [NSNull null])
//                        jsonList.mutDictActor = nil;
//                    else
//                        jsonList.mutDictActor = [discJson objectForKey:@"actor"];
//                    
//                    if([discJson objectForKey:@"repo"] == [NSNull null])
//                        jsonList.mutDictRepo = nil;
//                    else
//                        jsonList.mutDictRepo = [discJson objectForKey:@"repo"];
//                    
//                    if([discJson objectForKey:@"payload"] == [NSNull null])
//                        jsonList.mutDictPayload = nil;
//                    else
//                        jsonList.mutDictPayload = [discJson objectForKey:@"payload"];
//                    
//                    if([discJson objectForKey:@"public"] == [NSNull null])
//                        jsonList.isPublic = FALSE;
//                    else
//                        jsonList.isPublic = [[discJson objectForKey:@"public"]boolValue];

                    
//                    if([discJson objectForKey:@"created_at"] == [NSNull null])
//                        jsonList.strCreatedAt = @"";
//                    else
//                        jsonList.strCreatedAt = [discJson objectForKey:@"created_at"];
//
                    
            
                    [tmpArrJsonList addObject:jsonList];
                    
                }
            
            [self.delegate parsingCompleteWithSuccess:@"Json Parsing Successful" :tmpArrJsonList];
            //sucess
        }
    }
}

-(void)parseCityList
{
    if(dataOfferList == nil)
    {
        [delegate parsingFailedWithError:@"Internet connection not currently available."];
    }
    else
    {
        NSString *strResponse = [[NSString alloc] initWithData:dataOfferList encoding:NSStringEncodingConversionAllowLossy];
        
        NSLog(@"Response Data For Offer List :- %@", strResponse);
        
        dataOfferList = [strResponse dataUsingEncoding:NSUTF8StringEncoding];
        
        NSError *jsonError;
        
        NSDictionary *dictData = [[NSDictionary alloc]init];

        dictData = [NSJSONSerialization JSONObjectWithData:dataOfferList
                                                               options:kNilOptions
                                                                 error:&jsonError];
        
        if(jsonError != nil)
        {
            [delegate parsingFailedWithError:[NSString stringWithFormat:NSLocalizedString(@"Text-Alert-JSON-Error", nil)]];
            
            [self.delegate parsingFailedWithError:@"Json Parsing Fail"];
        }
        
        else
        {
            NSDictionary *dictRoot = [[NSDictionary alloc]init];
            
            dictRoot = [dictData objectForKey:@"root"];
            
            NSString *strStatus = [dictRoot objectForKey:@"status"];
            NSString *strMessage = [dictRoot objectForKey:@"message"];
            
            if ([strStatus isEqual:@"1"])
            {

                arrCitylist = [[NSMutableArray alloc]init];
                
                NSArray *arrTempCityList = [dictRoot objectForKey:@"cityList"];
                
                for (int i=0; i<[arrTempCityList count]; i++)
                {
                   
                    NSDictionary *dictCount = [arrTempCityList objectAtIndex:i];
            
                    JsonList *jsonList = [[JsonList alloc]init];
                    
                    if([dictCount objectForKey:@"id"] != [NSNull null])
                        jsonList.strId = [dictCount objectForKey:@"id"];
                    else
                        jsonList.strId = @"";
                    
                    if([dictCount objectForKey:@"categoryName"] != [NSNull null])
                        jsonList.strCategoryName = [dictCount objectForKey:@"categoryName"];
                    else
                        jsonList.strCategoryName = @"";
                    
                    if([dictCount objectForKey:@"cityName"] != [NSNull null])
                        jsonList.strCityName = [dictCount objectForKey:@"cityName"];
                    else
                        jsonList.strCityName = @"";
                    
                    if([dictCount objectForKey:@"hotDealValue"] != [NSNull null])
                        jsonList.strHotDealValue = [dictCount objectForKey:@"hotDealValue"];
                    else
                        jsonList.strHotDealValue = @"";
                    
                    if([dictCount objectForKey:@"subCategoryId"] != [NSNull null])
                        jsonList.strSubCatName = [dictCount objectForKey:@"subCategoryId"];
                    else
                        jsonList.strSubCatName = @"";
                    
                    if([dictCount objectForKey:@"subCategoryName"] != [NSNull null])
                        jsonList.strCategoryName = [dictCount objectForKey:@"subCategoryName"];
                    else
                        jsonList.strCategoryName = @"";
                    
                    if([dictCount objectForKey:@"cityImage"] != [NSNull null])
                        jsonList.strCityImage = [dictCount objectForKey:@"cityImage"];
                    else
                        jsonList.strCityImage = @"";
                    
//                    if([dictCount objectForKey:@"hotDealFlag"] != [NSNull null])
//                        jsonList.hotDealFlag = [dictCount objectForKey:@"hotDealFlag"];
//                    else
//                        jsonList.hotDealFlag = @"";
                    
                    [arrCitylist addObject:jsonList];
                }
                
                [self.delegate parsingCompleteWithSuccess:strMessage :arrCitylist];
            }
            else
            {
                [self.delegate parsingFailedWithError:@"Error in parsing"];
            }
        }
    }
}
@end