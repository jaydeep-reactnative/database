//
//  JsonList.m
//  JsonDemo
//
//  Created by Tosc163 on 25/08/16.
//  Copyright © 2016 SQUAD. All rights reserved.
//

#import "JsonList.h"

@implementation JsonList

@synthesize strId;

@synthesize strCategoryName;

@synthesize strCityName;

@synthesize strCityImage;

@synthesize strHotDealValue;

@synthesize strSubCatName;

@synthesize hotDealFlag;

@end
