//
//  JsonHelper.h
//  JsonDemo
//
//  Created by Tosc163 on 25/08/16.
//  Copyright © 2016 SQUAD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JsonParser.h"

#pragma mark -
#pragma mark HELPER DELEGATE -

@protocol jsonHelperDelegate <NSObject>

@required

-(void)jsonListSuccess: (NSString *)successMessage : (NSArray *)arrData;

-(void)jsonListFailure: (NSString *)errorMessage;

@end


#pragma mark -
#pragma mark HELPER INTERFACE -

@interface JsonHelper : NSObject

@property (weak,nonatomic) id<jsonHelperDelegate> delegate;

@property (nonatomic , strong) NSString *strSubmitURL;

@property ParsingTypeOfferList parsingType;

-(void)jsonData;



@end
