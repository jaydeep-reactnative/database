//
//  TableViewCell.h
//  JsonDemo
//
//  Created by Tosc163 on 25/08/16.
//  Copyright © 2016 SQUAD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *lblCityName;

@property (strong, nonatomic) IBOutlet UIImageView *ivCityImage;

@end
