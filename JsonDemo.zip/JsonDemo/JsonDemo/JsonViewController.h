//
//  JsonViewController.h
//  JsonDemo
//
//  Created by Tosc163 on 25/08/16.
//  Copyright © 2016 SQUAD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JsonViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>

@property (strong, nonatomic) IBOutlet UITableView *tableView;

@property (strong, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;

@end
