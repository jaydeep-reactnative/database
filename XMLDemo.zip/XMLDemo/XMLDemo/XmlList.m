//
//  XmlList.m
//  XMLDemo
//
//  Created by Tosc163 on 30/08/16.
//  Copyright © 2016 SQUAD. All rights reserved.
//

#import "XmlList.h"

@implementation XmlList

@synthesize strTitle;

@synthesize strArtist;

@synthesize strCountry;

@synthesize strCompany;

@synthesize strPrice;

@synthesize strYear;

@end
