//
//  XmlParser.m
//  XMLDemo
//
//  Created by Tosc163 on 30/08/16.
//  Copyright © 2016 SQUAD. All rights reserved.
//

#import "XmlParser.h"
#import "AppDelegate.h"

@interface XmlParser() <NSXMLParserDelegate>

{
    AppDelegate *appDelegate;

    NSUserDefaults *prefs;

    NSData *dataOfferList;

    ParsingTypeOfferList type;
    
    NSMutableArray *arrXMLData;
    
    XmlList *xmlList;
    
    NSString *currentValue;
    
    NSMutableArray *arrTemp;
    
    NSXMLParser *nsXmlParser;
    
}

@end


@implementation XmlParser

-(id)initUsingData: (NSData *)data type : (ParsingTypeOfferList)parsingTypeOfferList
{
    if(self = [super init])
    {
        appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
        
        prefs = [NSUserDefaults standardUserDefaults];
        
        dataOfferList = data;
        
        type = parsingTypeOfferList;
        
        return self;
    }
    
    return nil;
}

-(void)parse
{
    if (type == PARSING_JOSN_OFFER_LIST)
    {
        
    }
    if (type == PARSING_XML_OFFER_LIST)
    {
        [self parseCatalog];
    }
}


-(void)parseCatalog
{
        nsXmlParser = [[NSXMLParser alloc]initWithData:dataOfferList];
    
        [nsXmlParser setDelegate:self];
    
        [nsXmlParser parse];
    
        NSLog(@"%@",nsXmlParser);
}

- (void)parserDidStartDocument:(NSXMLParser *)parser
{

}
- (void)parserDidEndDocument:(NSXMLParser *)parser
{
    [self.delegate parsingCompleteWithSuccess:@"" :arrTemp];
}

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
    if ([elementName isEqualToString:@"CTALOG"])
    {
       
    }
    
    if ([elementName isEqualToString:@"CD"])
    {
        xmlList = [[XmlList alloc]init];
    }
    
    arrTemp = [[NSMutableArray alloc]init];
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    
    NSLog(@"%@",string);
    
    currentValue = string;
    
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
    if ([elementName isEqualToString:@"TITLE"])
    {
        xmlList.strTitle = currentValue;
    }
    if ([elementName isEqualToString:@"ARTIST"])
    {
       xmlList.strArtist = currentValue;
    }
    if ([elementName isEqualToString:@"COUNTRY"])
    {
        xmlList.strCountry = currentValue;
    }
    if ([elementName isEqualToString:@"COMPANY"])
    {
        xmlList.strCompany = currentValue;
    }
    if ([elementName isEqualToString:@"PRICE"])
    {
        xmlList.strPrice = currentValue;
    }
    if ([elementName isEqualToString:@"YEAR"])
    {
        xmlList.strYear = currentValue;
    }
    
    if([elementName isEqualToString:@"CD"])
    {
        [arrTemp addObject:xmlList];
    }
    
    currentValue = nil;
    
}

@end