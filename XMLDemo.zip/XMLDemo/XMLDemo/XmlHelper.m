//
//  XmlHelper.m
//  XMLDemo
//
//  Created by Tosc163 on 30/08/16.
//  Copyright © 2016 SQUAD. All rights reserved.
//

#import "XmlHelper.h"


@interface XmlHelper() <XmlParserDelegate,NSXMLParserDelegate>
{
    XmlParser *xmlParser;
    
    NSMutableURLRequest *request;
}

@end


@implementation XmlHelper

@synthesize strSubmitURL;

@synthesize parsingType;

-(void) parsingCompleteWithSuccess: (NSString *)successMessage : (NSArray *)arrData
{
    [self.delegate xmlListSuccess:@"" :arrData];
}

-(void) parsingFailedWithError:(NSString *)errorMessage
{
    [self.delegate xmlListFailure:@""];

}

-(void)xmlData
{
    NSOperationQueue *queue = [[NSOperationQueue alloc]init];
    
    request = [[NSMutableURLRequest alloc]init];
    
    [request setURL:[NSURL URLWithString:strSubmitURL]];
    
    [request setHTTPMethod:@"GET"];
    
    [NSURLConnection sendAsynchronousRequest:request queue:queue completionHandler:^(NSURLResponse *response, NSData * data, NSError *  connectionError)
    {
        if(data)
        {
            xmlParser = [[XmlParser alloc]initUsingData:data type:parsingType];
            
            xmlParser.delegate = self;
            
            [xmlParser parse];
        }
    }];
}

@end
