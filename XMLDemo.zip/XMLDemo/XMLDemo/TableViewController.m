//
//  TableViewController.m
//  XMLDemo
//
//  Created by Tosc163 on 30/08/16.
//  Copyright © 2016 SQUAD. All rights reserved.
//

#import "TableViewController.h"
#import "TableViewCell.h"

@interface TableViewController ()<xmlHelperDelegate>
{
    XmlHelper *tempXmlHelper;
    
    NSMutableArray *arrFinal;
}
@end

@implementation TableViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self xmlParsing];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 47;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrFinal count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *strIdentifier = @"TableViewCell";
    
    TableViewCell *tableViewCell= (TableViewCell *)[tableView dequeueReusableCellWithIdentifier:strIdentifier];
    
    if(tableViewCell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle]loadNibNamed:strIdentifier owner:self options:nil];
        tableViewCell = nib[0];
    }
    
    [tableViewCell.lblTitle setText:[arrFinal objectAtIndex:ar]];
    
    return tableViewCell;
}

-(void)xmlParsing
{
    tempXmlHelper = [[XmlHelper alloc]init];
    
    tempXmlHelper.strSubmitURL = @"http://www.w3schools.com/xml/cd_catalog.xml";
    
    tempXmlHelper.parsingType = PARSING_XML_OFFER_LIST;
    
    tempXmlHelper.delegate = self;
    
    [tempXmlHelper xmlData];
}



-(void)xmlListSuccess: (NSString *)successMessage : (NSArray *)arrData
{
    arrFinal = [arrData mutableCopy];
    
    NSLog(@"%@",arrFinal);
}

-(void)xmlListFailure:(NSString *)errorMessage
{
    
}

@end
