//
//  XmlParser.h
//  XMLDemo
//
//  Created by Tosc163 on 30/08/16.
//  Copyright © 2016 SQUAD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "XmlList.h"


typedef NS_ENUM(NSUInteger,ParsingTypeOfferList)
{
    PARSING_JOSN_OFFER_LIST,
    PARSING_XML_OFFER_LIST
};

@protocol XmlParserDelegate <NSObject>

@required

-(void) parsingCompleteWithSuccess: (NSString *)successMessage : (NSArray *)arrData;

-(void) parsingFailedWithError:(NSString *)errorMessage;

@end

@interface XmlParser : NSObject

@property (weak, nonatomic) id<XmlParserDelegate>delegate;

-(void)parse;

-(id)initUsingData: (NSData *)data type : (ParsingTypeOfferList)parsingTypeOfferList;

@end
