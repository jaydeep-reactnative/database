//
//  TableViewCell.m
//  XMLDemo
//
//  Created by Tosc163 on 30/08/16.
//  Copyright © 2016 SQUAD. All rights reserved.
//

#import "TableViewCell.h"

@implementation TableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
