//
//  main.m
//  XMLDemo
//
//  Created by Tosc163 on 30/08/16.
//  Copyright © 2016 SQUAD. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
